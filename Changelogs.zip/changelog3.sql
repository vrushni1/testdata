--liquibase formatted sql

--changeset user:3
ALTER TABLE users ADD COLUMN last_login TIMESTAMP;

--rollback ALTER TABLE users DROP COLUMN last_login;

--changeset user:4
CREATE INDEX idx_username ON users (username);

--rollback DROP INDEX idx_username ON users;